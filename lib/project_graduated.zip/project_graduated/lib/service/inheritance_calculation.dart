class InheritanceCalculator {
  static Map<String, double> calculateInheritance(
      {required double totalAssets,
      required double totalLiabilities,
      required bool hasChildren,
      required bool hasSpouse,
      required bool isWidow,
      required bool hasFather,
      required bool hasMother,
      required bool hasDaughters,
      required bool hasSons,
      required bool hasSisters,
      required bool hasBrothers,
      required bool hasSiblings,
      required bool hasParents}) {
    double netEstate = totalAssets - totalLiabilities;
    double remainingEstate = netEstate;
    Map<String, double> shares = {};

    // Spouse Share
    if (hasSpouse) {
      if (isWidow) {
        if (hasChildren) {
          shares['Widow'] = netEstate * 0.125;
        } else {
          shares['Widow'] = netEstate * 0.25;
        }
      } else {
        if (hasChildren) {
          shares['Husband'] = netEstate * 0.25;
        } else {
          shares['Husband'] = netEstate * 0.5;
        }
      }
      remainingEstate -= shares[isWidow ? 'Widow' : 'Husband']!;
    }

    // Parent Shares
    if (hasFather) {
      if (hasChildren) {
        shares['Father'] = netEstate * 0.1667;
      } else {
        shares['Father'] = remainingEstate;
      }
      remainingEstate -= shares['Father']!;
    }
    if (hasMother) {
      if (!hasChildren && !hasSiblings) {
        shares['Mother'] = netEstate * 0.333;
      } else if (hasFather && hasSpouse) {
        shares['Mother'] = (remainingEstate - shares['Father']!) * 0.333;
      } else {
        shares['Mother'] = netEstate * 0.1667;
      }
      remainingEstate -= shares['Mother']!;
    }

    // Child Shares
    if (hasDaughters && !hasSons) {
      shares['Daughters'] = remainingEstate * 0.6667;
    } else if (hasDaughters && hasSons) {
      shares['Daughters'] = remainingEstate * 0.3333 / 2;
      shares['Sons'] = remainingEstate * 0.6667;
    } else if (hasSons) {
      shares['Sons'] = remainingEstate;
    }

    // Sister Shares
    if (hasSisters && !hasBrothers && !hasChildren && !hasParents) {
      shares['Sisters'] = remainingEstate * 0.6667;
    } else if (hasSisters && hasBrothers && !hasChildren && !hasParents) {
      shares['Sisters'] = remainingEstate * 0.3333;
      shares['Brothers'] = remainingEstate * 0.6667;
    } else if (hasBrothers) {
      shares['Brothers'] = remainingEstate;
    }

    return shares;
  }
}
