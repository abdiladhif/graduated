import 'package:flutter/material.dart';

class ResultsDisplayScreen extends StatelessWidget {
  final Map<String, double> shares;

  ResultsDisplayScreen({required this.shares});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Results Display'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: ListView.builder(
          itemCount: shares.length,
          itemBuilder: (context, index) {
            String heir = shares.keys.elementAt(index);
            double share = shares[heir]!;
            return ListTile(
              title: Text('$heir: \$${share.toStringAsFixed(2)}'),
            );
          },
        ),
      ),
    );
  }
}
