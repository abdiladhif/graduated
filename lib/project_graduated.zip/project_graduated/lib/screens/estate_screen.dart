import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:project_graduated/service/inheritance_calculation.dart';

import 'inheritance_calculation_screen.dart';

class EstateInputScreen extends StatefulWidget {
  @override
  _EstateInputScreenState createState() => _EstateInputScreenState();
}

class _EstateInputScreenState extends State<EstateInputScreen> {
  final _formKey = GlobalKey<FormState>();
  final box = GetStorage();

  TextEditingController assetController = TextEditingController();
  TextEditingController liabilityController = TextEditingController();
  TextEditingController childrenController = TextEditingController();
  TextEditingController siblingsController = TextEditingController();
  TextEditingController daughtersController = TextEditingController();
  TextEditingController sonsController = TextEditingController();
  TextEditingController sistersController = TextEditingController();
  TextEditingController brothersController = TextEditingController();

  bool hasSpouse = false;
  bool isWidow = false;
  bool hasFather = false;
  bool hasMother = false;
  bool hasParents = false;
  bool isMale = true; // Gender of the deceased

  void _submitEstateDetails() {
    if (_formKey.currentState!.validate()) {
      double totalAssets = double.parse(assetController.text);
      double totalLiabilities = double.parse(liabilityController.text);
      int numChildren = int.parse(childrenController.text);
      int numSiblings = int.parse(siblingsController.text);
      int numDaughters = int.parse(daughtersController.text);
      int numSons = int.parse(sonsController.text);
      int numSisters = int.parse(sistersController.text);
      int numBrothers = int.parse(brothersController.text);

      Map<String, double> shares = InheritanceCalculator.calculateInheritance(
        totalAssets: totalAssets,
        totalLiabilities: totalLiabilities,
        hasChildren: numChildren > 0,
        hasSpouse: hasSpouse,
        isWidow: isWidow,
        hasFather: hasFather,
        hasMother: hasMother,
        hasDaughters: numDaughters > 0,
        hasSons: numSons > 0,
        hasSisters: numSisters > 0,
        hasBrothers: numBrothers > 0,
        hasSiblings: numSiblings > 0,
        hasParents: hasParents,
      );

      box.write('totalAssets', totalAssets);
      box.write('totalLiabilities', totalLiabilities);
      box.write('shares', shares);

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => InheritanceCalculationScreen(shares: shares),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Estate Input'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: assetController,
                decoration: InputDecoration(
                  labelText: 'Assets',
                  hintText: 'Enter total assets',
                  filled: true,
                  fillColor: Colors.grey[200],
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter total assets';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: liabilityController,
                decoration: InputDecoration(
                  labelText: 'Liabilities',
                  hintText: 'Enter total liabilities',
                  filled: true,
                  fillColor: Colors.grey[200],
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter total liabilities';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              DropdownButtonFormField<bool>(
                value: isMale,
                decoration: InputDecoration(
                  labelText: 'Gender of the Deceased',
                  filled: true,
                  fillColor: Colors.grey[200],
                ),
                onChanged: (bool? newValue) {
                  setState(() {
                    isMale = newValue!;
                  });
                },
                items: [
                  DropdownMenuItem(
                    value: true,
                    child: Text('Male'),
                  ),
                  DropdownMenuItem(
                    value: false,
                    child: Text('Female'),
                  ),
                ],
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: childrenController,
                decoration: InputDecoration(
                  labelText: 'Number of Children',
                  hintText: 'Enter number of children',
                  filled: true,
                  fillColor: Colors.grey[200],
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter number of children';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: siblingsController,
                decoration: InputDecoration(
                  labelText: 'Number of Siblings',
                  hintText: 'Enter number of siblings',
                  filled: true,
                  fillColor: Colors.grey[200],
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter number of siblings';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: daughtersController,
                decoration: InputDecoration(
                  labelText: 'Number of Daughters',
                  hintText: 'Enter number of daughters',
                  filled: true,
                  fillColor: Colors.grey[200],
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter number of daughters';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: sonsController,
                decoration: InputDecoration(
                  labelText: 'Number of Sons',
                  hintText: 'Enter number of sons',
                  filled: true,
                  fillColor: Colors.grey[200],
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter number of sons';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: sistersController,
                decoration: InputDecoration(
                  labelText: 'Number of Sisters',
                  hintText: 'Enter number of sisters',
                  filled: true,
                  fillColor: Colors.grey[200],
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter number of sisters';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: brothersController,
                decoration: InputDecoration(
                  labelText: 'Number of Brothers',
                  hintText: 'Enter number of brothers',
                  filled: true,
                  fillColor: Colors.grey[200],
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter number of brothers';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              SwitchListTile(
                title: Text('Has Spouse'),
                value: hasSpouse,
                onChanged: (value) {
                  setState(() {
                    hasSpouse = value;
                  });
                },
              ),
              if (hasSpouse)
                SwitchListTile(
                  title: Text('Is Widow'),
                  value: isWidow,
                  onChanged: (value) {
                    setState(() {
                      isWidow = value;
                    });
                  },
                ),
              SwitchListTile(
                title: Text('Has Father'),
                value: hasFather,
                onChanged: (value) {
                  setState(() {
                    hasFather = value;
                  });
                },
              ),
              SwitchListTile(
                title: Text('Has Mother'),
                value: hasMother,
                onChanged: (value) {
                  setState(() {
                    hasMother = value;
                  });
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitEstateDetails,
                child: Text(
                  'Submit',
                  style: TextStyle(color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
