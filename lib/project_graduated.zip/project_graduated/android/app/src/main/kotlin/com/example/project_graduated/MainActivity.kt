package com.example.project_graduated

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
